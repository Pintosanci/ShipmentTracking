package com.spring.order.entity;


public class ShipmentStatus {

    private String status;
    private String currentLocation;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public ShipmentStatus(String status, String currentLocation) {
        super();
        this.status = status;
        this.currentLocation = currentLocation;
    }

    public ShipmentStatus() {
        super();
    }

    @Override
    public String toString() {
        return "ShipmentStatus{" +
                "status='" + status + '\'' +
                ", currentLocation='" + currentLocation + '\'' +
                '}';
    }
}
