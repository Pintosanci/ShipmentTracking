package com.spring.order.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Data
public class OrderItems
{

    @Id
    private Integer orderId;
    private String productName;
    private String customerMail;
    private Integer quantity;
    private String address;
    private BigDecimal price;
}
