package com.spring.order.service;


import com.spring.order.entity.Shipment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;


@Service
public class ShipmentConsumer {
    private static final Logger logger = LoggerFactory.getLogger(ShipmentConsumer.class);

    @Autowired
    private EmailService emailService;

    @KafkaListener(topics = "shipment", groupId = "shipment_email_group")
    public void listenShipment(Shipment shipment) {
        try {
            logger.info("Received shipment message: {}", shipment);
            emailService.sendShipmentUpdateNotification(shipment); // Send email notification
        } catch (Exception e) {
            logger.error("Error processing shipment: {}", e.getMessage(), e);
        }
    }
}