package com.spring.order.service;

import com.spring.order.entity.OrderItems;
import com.spring.order.entity.Shipment;
import com.spring.order.entity.ShipmentStatus;
import com.spring.order.repo.ShipmentRepo;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService {

    private static final Logger logger = LoggerFactory.getLogger(ShipmentService.class);

    @Autowired
    private ShipmentRepo shipmentRepo;

    @Autowired
    private ShipmentProducer shipmentProducer;

    @Autowired
    private ShipmentConsumer shipmentConsumer;

    @KafkaListener(topics = "shipment", groupId = "shipment_email_group")
    public void consumeShipment(Shipment shipment) {
        shipmentRepo.save(shipment);
    }
    public Shipment getShipment(Long trackingid) {
        return shipmentRepo.findById(trackingid)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id " + trackingid));
    }

    public Shipment updateShipmentStatus(Long trackingid, ShipmentStatus statusUpdate) {
        Shipment shipment = shipmentRepo.findById(trackingid)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id " + trackingid));
        shipment.setStatus(statusUpdate.getStatus());
        shipment.setCurrentLocation(statusUpdate.getCurrentLocation());
        Shipment updatedShipment = shipmentRepo.save(shipment);

        logger.info("Created shipment: {}", updatedShipment);
        shipmentProducer.sendMessage("Shipment","Sancia",updatedShipment);// Publish shipment update to Kafka

        logger.info("Published shipment to Kafka: {}", updatedShipment);  // Log the message being sent to Kafka
        shipmentConsumer.listenShipment(updatedShipment);
        return updatedShipment;
    }

    public Shipment createShipmentFromOrder(OrderItems orderItems) {
        try {
            Shipment shipment = new Shipment(orderItems);
            Shipment savedShipment = shipmentRepo.save(shipment);

            logger.info("Created shipment: {}", savedShipment); // Log the created shipment
            shipmentProducer.sendMessage("Shipment","Sancia",savedShipment); // Publish shipment update to Kafka

            logger.info("Published shipment to Kafka: {}", savedShipment); // Log the message being sent to Kafka
            shipmentConsumer.listenShipment(savedShipment);// Consume shipment update from Kafka
            return savedShipment;

        } catch (Exception e) {
            logger.error("An error occurred while creating the shipment: {}", e.getMessage());
            throw new RuntimeException("An error occurred while creating the shipment", e);
        }
    }

}

