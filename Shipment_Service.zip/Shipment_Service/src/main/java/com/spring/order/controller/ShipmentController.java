package com.spring.order.controller;

import com.spring.order.entity.OrderItems;
import com.spring.order.entity.Shipment;
import com.spring.order.entity.ShipmentStatus;
import com.spring.order.service.ShipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/shipping")
public class ShipmentController {

    @Autowired
    private ShipmentService shipmentService;


    @PostMapping("/")
    public ResponseEntity<?> createShipmentFromOrder(@RequestBody OrderItems orderItems) {
        try {
            Shipment createdShipment = shipmentService.createShipmentFromOrder(orderItems);
            System.out.println("Email notification sent successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(createdShipment);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while creating the shipment: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Shipment> getShipment(@PathVariable Long id) {
        Shipment shipment = shipmentService.getShipment(id);
        return ResponseEntity.ok(shipment);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Shipment> updateShipmentStatus(@PathVariable Long id, @RequestBody ShipmentStatus statusUpdate) {
        Shipment updatedShipment = shipmentService.updateShipmentStatus(id, statusUpdate);
        System.out.println("Email notification sent successfully");
        return ResponseEntity.ok(updatedShipment);
    }
}
