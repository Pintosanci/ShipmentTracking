package com.spring.order.repo;

import com.spring.order.entity.OrderItems;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepo extends JpaRepository<OrderItems, Integer> {
}
