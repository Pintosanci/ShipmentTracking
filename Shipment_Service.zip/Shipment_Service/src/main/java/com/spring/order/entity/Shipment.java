package com.spring.order.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "shipmenttb")
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long trackingid;
    private Integer orderId;
    private String origin;
    private String destination;
    private String status;
    private String currentLocation;
    private LocalDate estimatedDeliveryDate;



    public Long getTrackingid() {
        return trackingid;
    }

    public void setTrackingid(Long trackingid) {
        this.trackingid = trackingid;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public LocalDate getEstimatedDeliveryDate() {
        return estimatedDeliveryDate;
    }

    public void setEstimatedDeliveryDate(LocalDate estimatedDeliveryDate) {
        this.estimatedDeliveryDate = estimatedDeliveryDate;
    }

    public Shipment() {
        super();
    }

    public Shipment(Long trackingid, Integer orderId, String origin, String destination, String status, String currentLocation, LocalDate estimatedDeliveryDate) {
        super();
        this.trackingid = trackingid;
        this.orderId = orderId;
        this.origin = origin;
        this.destination = destination;
        this.status = status;
        this.currentLocation = currentLocation;
        this.estimatedDeliveryDate = estimatedDeliveryDate;
    }

    @Override
    public String toString() {
        return "Shipment{" +
                "trackingid=" + trackingid +
                ", orderId='" + orderId + '\'' +
                ", origin='" + origin + '\'' +
                ", destination='" + destination + '\'' +
                ", status='" + status + '\'' +
                ", currentLocation='" + currentLocation + '\'' +
                ", estimatedDeliveryDate=" + estimatedDeliveryDate +
                '}';
    }

    public Shipment(OrderItems order){
        this.orderId = order.getOrderId();
        this.origin = "Warehouse:6th Floor, DLF Centre, Sansad Marg, New Delhi-110001"; // Assuming a default origin for now
        this.destination = order.getAddress();
        this.status = "SHIPPED";
        this.currentLocation="Warehouse:6th Floor, DLF Centre, Sansad Marg, New Delhi-110001";
        this.estimatedDeliveryDate = LocalDate.now().plusDays(3);
    }


}
