package com.spring.order.service;


import com.spring.order.entity.Shipment;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    // Method to send email notifications
    public void sendShipmentUpdateNotification(Shipment shipment) {
        try {
            logger.info("Preparing to send email notification for shipment: {}", shipment);

            Properties properties = new Properties();
            properties.setProperty("mail.smtp.host", "smtp.gmail.com");
            properties.setProperty("mail.smtp.auth", "true"); // Enable authentication
            properties.setProperty("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
            properties.setProperty("mail.smtp.port", "587"); // Port for STARTTLS

            Session session = Session.getInstance(properties, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("rohitamuthan45@gmail.com", "oalk jtuw guwi zjtu");
                }
            });

               //compose the message
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress("rohitamuthan45@gmail.com"));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress("sancipinto27@gmail.com"));
                message.setSubject("Shipment Update: " + shipment.getStatus());
                message.setText("Your shipment with ID " + shipment.getTrackingid() +
                    " is now " + shipment.getStatus() + ".\n" +
                    "Current Location: " + shipment.getCurrentLocation() + "\n" +
                    "Estimated Delivery Date: " + shipment.getEstimatedDeliveryDate());

                // Send message
                Transport.send(message);
                System.out.println("message sent successfully....");
                logger.info("Email notification sent successfully for shipment: {}", shipment);
            } catch (MessagingException mex) {
                mex.printStackTrace();
                logger.error("Failed to send email notification for shipment: {}", shipment, mex);
            }
        }
    }






















        // Send email
            //email.send(message);

//            logger.info("Email notification sent successfully for shipment: {}", shipment);
//        } catch (MailException e) {
//            logger.error("Failed to send email notification for shipment: {}", shipment, e);
//            // Handle the exception (e.g., retry, log, notify administrator)
//        }
//    }
//}
